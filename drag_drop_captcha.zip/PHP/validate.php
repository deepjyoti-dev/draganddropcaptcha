
<?php
$x = $_POST['dropX'];
$y = $_POST['dropY'];
if (abs($x - 120) <= 10 && abs($y - 60) <= 10) {
    echo "✅ CAPTCHA passed!";
} else {
    echo "❌ CAPTCHA failed.";
}
?>
